
import requests

def fetch_binance_data(symbol="WIFUSDC"):
    url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval=15m&limit=100"
    response = requests.get(url)
    data = response.json()
    return [{
        "time": k[0], "open": float(k[1]), "high": float(k[2]),
        "low": float(k[3]), "close": float(k[4]), "volume": float(k[5])
    } for k in data]

def calculate_indicators(prices):
    closes = [p["close"] for p in prices]
    ma7 = sum(closes[-7:]) / 7 if len(closes) >= 7 else closes[-1]
    ma25 = sum(closes[-25:]) / 25 if len(closes) >= 25 else closes[-1]
    return {
        "ma7": ma7,
        "ma25": ma25,
        "last_close": closes[-1] if closes else 0
    }

def get_ai_analysis(indicators):
    trend = "wzrostowy" if indicators["ma7"] > indicators["ma25"] else "spadkowy"
    return f"Trend {trend}. Cena: {indicators['last_close']:.4f}. MA7: {indicators['ma7']:.4f}, MA25: {indicators['ma25']:.4f}."
