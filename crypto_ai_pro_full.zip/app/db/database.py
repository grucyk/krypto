
import sqlite3

def init_db():
    conn = sqlite3.connect("app/db/transactions.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    type TEXT,
                    price REAL,
                    amount REAL
                )''')
    conn.commit()
    conn.close()

def save_transaction(type, price, amount):
    conn = sqlite3.connect("app/db/transactions.db")
    c = conn.cursor()
    c.execute("INSERT INTO transactions (type, price, amount) VALUES (?, ?, ?)", (type, price, amount))
    conn.commit()
    conn.close()

def get_transactions():
    conn = sqlite3.connect("app/db/transactions.db")
    c = conn.cursor()
    c.execute("SELECT * FROM transactions ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    return rows
