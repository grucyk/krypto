
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from app.utils.analysis import get_ai_analysis, fetch_binance_data, calculate_indicators
from app.db.database import init_db, save_transaction, get_transactions

app = FastAPI()
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

init_db()

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    prices = fetch_binance_data()
    indicators = calculate_indicators(prices)
    ai_text = get_ai_analysis(indicators)
    transactions = get_transactions()
    return templates.TemplateResponse("index.html", {
        "request": request,
        "ai_text": ai_text,
        "prices": prices[-10:], 
        "transactions": transactions
    })

@app.post("/buy")
async def buy(price: float = Form(...), amount: float = Form(...)):
    save_transaction("BUY", price, amount)
    return RedirectResponse(url="/", status_code=303)
